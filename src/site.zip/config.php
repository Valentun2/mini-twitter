<?php
// src/config.php

return [
    'db_host' => 'sql308.infinityfree.com',       // Ім'я сервісу з docker-compose
    'db_name' => 'if0_40561948_XXX', // Назва БД з docker-compose
    'db_user' => 'if0_40561948',        // Користувач
    'db_pass' => 'WShCcQ2ffmt4J0', // Пароль
];
// WShCcQ2ffmt4J0
// if0_40561948